#! /bin/bash
uso() {
    echo "Uso $0 [-h] <origen> <destino>"
    echo "  -h      Muestra esta ayuda."
    echo "  origen  Directorio de origen para hacer el backup."
    echo "  destino Directorio de destino donde se almacenara el backup."
}

ejecutar_backup() {
    local origen=$1
    local destino=$2
    local fecha=$(date +%Y%m%d)
    local nombre_archivo=$(basename $origen)
    local nombre_backup="${nombre_archivo}_bkp_${fecha}.tar.gz"


    echo "Creando backup de $origen ..."
    tar -czf "$destino/$nombre_backup" -C "$(dirname $origen)" "$(basename $origen)"
    
    if [ $? -eq 0 ]; then
        echo "Backup creado exitosamente: $destino""$nombre_backup"
    else
        echo "Error al crear el backup"
        exit 1
    fi
}

OPCION_INVALIDA=0

while getopts ":h" option; do
    case $option in
        h)
            uso
            exit 0
            ;;
        ?)  
            OPCION_INVALIDA=1
            ;;
    esac
done

if [ $OPCION_INVALIDA -eq 1 ]; then
    uso
    exit 1
fi

if [ $# -lt 2 ]; then
    echo "Argumentos brindados $# esperados 2"
    uso
    exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d $ORIGEN ]; then
    echo "Error: El directorio origen $ORIGEN no existe."
    exit 1
fi

if  [ ! -d $DESTINO ]; then
    echo "Error: El directorio destino $DESTINO no existe."
    exit 1
fi

ejecutar_backup "$ORIGEN" "$DESTINO"
